g = 'y'
while g == 'Y' or g == 'y':
speed = int(input('Enter mph: '))
time = int(input('Enter hours: '))

if time <= 0 or speed <= 0:
    print('Invalid Hours and mph must be greater than 0')
else:
    for t in range(time):
        distance = speed * (t+1)        // Use t+1 instead of time

        print(t + 1,':', distance)
        # time = time * 2              // No need to double the time


    g = 'n'
print('End')

